package com.spring.spring.model;

public class User {
    private int id;
    private String Nom, Prenom;
    private String Contact;
    private String Email;
    private String Password;
    private boolean admin = false;


    public User(int id,String Nom,String Prenom, String Contact, String Email, boolean admin) {
        this.id=id; this.Nom = Nom; this.Prenom = Prenom;
        this.Contact = Contact; this.Email = Email; this.admin=admin;
    }
    //brand new user--> password needed
    public User(int id,String Nom,String Prenom, String Contact, String Email,String password, boolean admin) {
        this.id=id; this.Nom = Nom; this.Prenom = Prenom; this.Password= password;
        this.Contact = Contact; this.Email = Email; this.admin=admin;
    }
    public User() {
        this.id=id; this.Nom = Nom; this.Prenom = Prenom; this.Contact = Contact;
        this.Email = Email; this.Password = Password; this.admin = admin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return Nom;
    }
    public String getPrenom() {
        return Prenom;
    }
    public void setNom(String Nom) {
        this.Nom = Nom;
    }
    public void setPrenom(String Prenom) {
        this.Prenom = Prenom;
    }
    public String getContact() {
        return Contact;
    }
    public void setContact(String Contact) {
        this.Contact = Contact;
    }
    public String getEmail() {
        return Email;
    }
    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }
    public void setPassword(String Password) {
        this.Password = Password;
    }

    public void setAdmin(boolean permission){ this.admin=permission;}
    public int getAdmin(){
        if(admin) return 1;
        else return 0;
    }

    @Override
    public String toString() {
        return "User{" +
                "ID='" + id + '\'' +
                "Nom='" + Nom + '\'' +
                ", Prenom='" + Prenom + '\'' +
                ", Contact=" + Contact +
                ", Email='" + Email + '\'' +
                '}';
    }
}
