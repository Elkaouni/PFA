package com.spring.spring.model;

public class ServiceUnitaire extends Service{
    public ServiceUnitaire(){
        super();
    }
    public ServiceUnitaire(int id, String Nom, String DataIn, String DataOut, int Priorité, User Responsable, String Public_cible, String BDD) {
        super(id, Nom, DataIn, DataOut, Priorité, Responsable, Public_cible, BDD, false);

    }

    /*
    @Override
    public void setNext(IHandler next){
        this.chain= next;
    }

    @Override
    public void TryHandle(Requests request) //
    {
        if(request.getDone()) //gotta go through the children
            System.out.println("Request already handked.");
        else
            System.out.println("Request in progress.");
    }

     */
}
