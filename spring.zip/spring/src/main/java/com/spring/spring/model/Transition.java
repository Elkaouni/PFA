package com.spring.spring.model;

public class Transition {
}
