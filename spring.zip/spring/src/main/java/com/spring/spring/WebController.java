package com.spring.spring;

import com.spring.spring.dao.ServiceDao;
import com.spring.spring.model.Service;
import com.spring.spring.model.ServiceComposite;
import com.spring.spring.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class WebController {
    @Autowired
    private ServiceDao serviceDao;
    /////sign in menu
    @GetMapping(value = "/LogMenu")
    public String loginForm(Model model)
    {
        User person= new User();
        model.addAttribute("person",person);

        return "LogMenu";
    }
    @PostMapping(value = "/LogMenu")
    public String loginUser(@ModelAttribute("person")User person)
    {
        System.out.println(person);
        return"UserMenu";
    }

    @RequestMapping(value = "/UserMenu")
    public String logMenu(Model model){
        return "UserMenu";
    }
    /////sign in menu
    @GetMapping(value = "/SignInMenu")
    public String signForm(Model model)
    {
        User user= new User();
        model.addAttribute("user", user);

        return "SignInMenu";
    }
    @PostMapping(value = "/SignInMenu")
    public String submitForm(@ModelAttribute("user") User user)
    {
        System.out.println(user);
        //ajouterService(service
        serviceDao.addUser(user.getNom(),
                user.getPrenom(), user.getEmail(), user.getContact(),
                user.getPassword(), user.getAdmin());
        return "LogMenu";
    }

    @RequestMapping(value = "/LogMenu")
    public String defaultLogin(Model model){
        loginForm(model);
        return "LogMenu";
    }


    @RequestMapping(value = "/AdminMenu")
    public String menuAdmin(Model model)
    {
        return "AdminMenu";
    }

    @GetMapping(value = "/LogMenuAdmin")
    public String loginAdmin(Model model)
    {
        User admin= new User();
        model.addAttribute("admin",admin);
        return "LogMenuAdmin";
    }
    @PostMapping(value ="/LogMenuAdmin")
    public String adminMenu(@ModelAttribute("admin")User admin){
        System.out.println(admin);
        return "AdminMenu";
    }


    ///////User menu

    @RequestMapping(value = "/UserListOfRequests")
    public String userRequestList()
    {
        return "UserListOfRequests";
    }

    @RequestMapping(value = "/UserRequestService")
    public String userRequest()
    {
        return "UserRequestService";
    }



    //AdminMenu

    @RequestMapping(value="/ModProcessService")
    public String processRequest()
    {
        return "ModProcessService";
    }

    @RequestMapping(value="/ModListRequestedServices")
    public String adminRequestList()
    {
        return "ModListRequestedServices";
    }

    @RequestMapping(value="/ModListCreatedServices")
    public String adminServiceList()
    {
        return "ModListCreatedServices";
    }

    //serviceForm
    @RequestMapping(value = "/ModNewService")
    public String newService()
    {
        return "ModNewService";
    }

    @GetMapping(value = "/ModServiceForm")
    public String signServiceForm(Model model)
    {
        Service service= new Service();
        model.addAttribute("service", service);
        return "ModServiceForm";
    }
    @PostMapping(value = "/ModServiceForm")
    public String submitServiceForm(@ModelAttribute("service") Service service)
    {
        System.out.println(service);
        return "ModServiceForm";
    }

    ////////////////////functions/////////////////////////
    @RequestMapping(value = "/Services")
    public String afficherTousLesServices(Model model){
        List<Service> listeServices = serviceDao.findAllServices();
        model.addAttribute("list", listeServices);
        return "ModListCreatedServices";
    }

    @GetMapping(value = "/Admin/ervices/{id}")
    public ArrayList<Service> afficherUnService(@PathVariable int id){
        return serviceDao.findAllServices();
    }
    @PostMapping(value = "/Responsables")
    public void ajouterResponsable(@RequestBody User Responsable){
        serviceDao.addResp(Responsable.getId(), Responsable.getNom(), Responsable.getPrenom(),Responsable.getContact(), Responsable.getEmail());
    }

    public void ajout(Service noeud, int id_parent){
        if(!noeud.getComposite()){
            serviceDao.addService(noeud.getId_service(), noeud.getResponsable().getId(), id_parent, noeud.getNom(),
                    noeud.getPublic_cible(), noeud.getDataIn(), noeud.getDataOut(), noeud.getPriorite(), "unitaire",0 , noeud.getBDD());
            serviceDao.addResp(noeud.getResponsable().getId(), noeud.getResponsable().getNom(),noeud.getResponsable().getPrenom(),noeud.getResponsable().getContact(), noeud.getResponsable().getEmail());
        }
        else{
            serviceDao.addService(noeud.getId_service(), noeud.getResponsable().getId(), id_parent, noeud.getNom(),
                    noeud.getPublic_cible(), noeud.getDataIn(), noeud.getDataOut(), noeud.getPriorite(), "composite",((ServiceComposite)noeud).getChildren().size(), noeud.getBDD());
            serviceDao.addResp(noeud.getResponsable().getId(), noeud.getResponsable().getNom(),noeud.getResponsable().getPrenom(),noeud.getResponsable().getContact(), noeud.getResponsable().getEmail());
            for (Service child: ((ServiceComposite) noeud).getChildren()) {
                ajout(child, noeud.getId_service());
            }

        }
    }
    @PostMapping(value = "/Admin/services")
    public void ajouterService(@RequestBody Service service){
        ajout(service, 0);
    }
    @PostMapping(value = "/Signin")
    public void ajouterUtilisateur(@RequestBody User user){
        int admin=0;
        if(user.getAdmin()==1){admin=1;}
        serviceDao.addUser(user.getNom(), user.getPrenom(), user.getEmail(), user.getContact(), user.getPassword(), admin);
    }

    @GetMapping(value = "/Responsable/{id}")
    public User afficherResp(@PathVariable int id){
        return serviceDao.findResById(id);
    }
    @GetMapping(value = "/User/{id}")
    public User afficherUtilisateur(@PathVariable int id){
        return serviceDao.findUserById(id);
    }
    @GetMapping(value = "/Admin/services/{id}")
    public Service afficherService(@PathVariable int id){
        return serviceDao.findServiceById(id);
    }
    @GetMapping(value = "/delete/Responsable/{id}")
    public void supprimerResp(@PathVariable int id){
        serviceDao.removeResp(id);
    }
    @GetMapping(value = "/delete/User/{id}")
    public void supprimerUtilisateur(@PathVariable int id){
        serviceDao.removeUser(id);
    }
    @GetMapping(value = "/Admin//delete/Service/{id}")
    public void supprimerServiceRacine(@PathVariable int id){
        serviceDao.removeService(id);
    }


}
