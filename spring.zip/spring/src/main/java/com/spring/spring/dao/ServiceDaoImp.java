package com.spring.spring.dao;

import com.spring.spring.model.Service;
import com.spring.spring.model.ServiceComposite;
import com.spring.spring.model.ServiceUnitaire;
import com.spring.spring.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Repository
public class ServiceDaoImp implements ServiceDao{
    @Autowired
    private JdbcTemplate jt;

    @Override
    public ArrayList<Service> findListOfChildren(int idParent){
        return (ArrayList<Service>) jt.query("select * from services s join responsables r on s.id_resp=r.id where s.id_parent = ?",
                (ResultSet rs, int rowNum) -> {
                    if((rs.getString("structure")).equals("composite")){
                        return new ServiceComposite(Integer.parseInt(rs.getString("id")), rs.getString("nom")
                                , rs.getString("datain"), rs.getString("dataout"), rs.getInt("priorite")
                                , new User(rs.getInt("id_resp"), rs.getString("nom"),rs.getString("prenom"), rs.getString("contact"), rs.getString("email"),true )
                                , rs.getString("cible"),rs.getString("BDD"), true, findListOfChildren(Integer.parseInt(rs.getString("id"))));
                    }
                    return new ServiceUnitaire(Integer.parseInt(rs.getString("id")), rs.getString("nom")
                            , rs.getString("datain"), rs.getString("dataout"), rs.getInt("priorite")
                            , new User(rs.getInt("id_resp"), rs.getString("nom"),rs.getString("prenom"), rs.getString("contact"), rs.getString("email"),true )
                            , rs.getString("cible"),rs.getString("BDD"));
                }, idParent);

    }
    @Override
    public ArrayList<Service> findAllServices() {
        return findListOfChildren(0);
    }

    @Override
    public List<User> listUsers(){
        String sql="SELECT * FROM USERS";
        List<User> usersList = jt.query(sql,
                BeanPropertyRowMapper.newInstance(User.class));

        return usersList;
    }

    @Override
    public User findResById(int id) {
        return jt.queryForObject("select * from responsables where id= ? ", (rs, rowNum) ->
        (new User(rs.getInt("id"), rs.getString("nom"),
                        rs.getString("prenom"), rs.getString("contact"),
                        rs.getString("email"), true)),id);
    }
    public User findUserById(int id){
        return jt.queryForObject("select id, nom, prenom, email, contact, admin from users where id= ?", (rs, numRow)->
                (new User(rs.getInt("id"), rs.getString("nom"), rs.getString("prenom"),
                        rs.getString("contact"), rs.getString("email"),
                        (rs.getInt("admin")!=0))),id);
    }
    public Service findServiceById(int id){
        return jt.queryForObject("select * from services s join responsables r on s.id_resp=r.id where s.id=? "
                ,(ResultSet rs, int rowNum) -> {
                    if((rs.getString("structure")).equals("composite")){
                        return new ServiceComposite(Integer.parseInt(rs.getString("id")), rs.getString("nom")
                                , rs.getString("datain"), rs.getString("dataout"), rs.getInt("priorite")
                                , new User(rs.getInt("id_resp"), rs.getString("nom")
                                ,rs.getString("prenom"), rs.getString("contact"), rs.getString("email"), true )
                                , rs.getString("cible"),rs.getString("bdd"), true);
                    }
                    return new ServiceUnitaire(Integer.parseInt(rs.getString("id")), rs.getString("nom")
                            ,rs.getString("datain"), rs.getString("dataout"), rs.getInt("priorite")
                            , new User(rs.getInt("id_resp"), rs.getString("nom")
                            ,rs.getString("prenom"), rs.getString("contact"), rs.getString("email"), true ),
                            rs.getString("cible"), rs.getString("BDD"));
                }, id);
    }

    @Override
    public int addService(int id, int id_resp, int id_parent, String nom, String cible, String datain, String dataout, int priority, String structure, int nb_fils, String BDD) {
        return jt.update("insert into services values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                String.valueOf(id), nom, id_resp, cible, datain, dataout, priority, BDD, structure, nb_fils, String.valueOf(id_parent));
    }

    @Override
    public int addUser(String nom, String prenom, String email, String contact, String password, int admin) {
        return jt.update("insert into mika.users values(?, ?, ?, ?, ?, ?)", nom, prenom, email, contact, admin, password);
    }
    public int addResp(int id, String nom, String prenom, String contact, String email){
        return jt.update("insert into responsables values(?, ?, ?, ?, ?) ",id, nom, prenom, contact, email);
    }

    public int removeResp(int id){
        return jt.update("delete from responsables where id= ?",id);
    }
    public int removeUser(int id){
        return jt.update("delete from users where id= ?",id);
    }
    public void removeService(int id){
        List<Integer> L = new ArrayList<>();
        L=jt.query("select id from services where id_parent=?", (rs, rowNum) -> rs.getInt("id"),id);
        jt.update("delete from services where id=? ", id);
        for(int id_parent : L){
            removeService(id_parent);
        }

    }


    @Override
    public boolean authenticateUser(String email, String password){

        User test= new User();
        String sql= "Select email, password from Users" +
                " where email= "+ email + " and password = " +
                password;
    return true;
    }
}
