package com.spring.spring.model;

public class Requests {
    private Service requestWanted; //requete à traiter
    private User responsable; //le responsable
    private boolean done = false; //request

    public Requests(Service request)  {
        requestWanted= request;
        responsable = request.getResponsable();
    }
    public void setDone() { this.done= true;}
    public void resetDone() {this.done= false;}
    public Service getRequestWanted(){
        return requestWanted;
    }
    public User getResponsable() {
        return responsable;
    }
    public boolean getDone(){ return done;}
}
