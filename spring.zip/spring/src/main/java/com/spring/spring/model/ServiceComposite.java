package com.spring.spring.model;

import java.util.ArrayList;

public class ServiceComposite extends Service{
    private ArrayList<Service> children= new ArrayList<>();
    public ServiceComposite(int id, String nom, String dataIn, String dataOut, int priorite, User responsable, String public_cible, String BDD, boolean b){
        super();
    }
    public ServiceComposite(int id, String Nom, String DataIn, String DataOut, int Priorite, User Responsable, String Public_cible, String BDD) {
        super(id, Nom, DataIn, DataOut, Priorite, Responsable, Public_cible, BDD, true);
    }
    public ServiceComposite(int id,String Nom, String DataIn, String DataOut, int Priorite, User Responsable, String Public_cible, String BDD, Boolean composite, ArrayList<Service> children) {
        this(id, Nom, DataIn, DataOut, Priorite, Responsable, Public_cible, BDD,  true);
        this.children=children;
    }

    public ArrayList<Service> getChildren() {
        return children;
    }

    public void setChildren(ArrayList<Service> children) {
        this.children = children;
    }

    public void addChild(Service child) {
        children.add(child);
    }
    public void removeChild(int id) {
        children.remove(id);
    }

    //private IHandler chain;
    public ArrayList<IHandler> Handlers = new ArrayList<IHandler>();

    /*
    @Override
    public void setNext(IHandler next){
        this.chain= next;
    }

    @Override
    public void TryHandle(Requests request) //
    {
        if(request.getDone()== true) //gotta go through the children
            System.out.println("Request (cmp) already handked.");
        else
            System.out.println("Request (cmp) in progress.");
    }
     */
}
