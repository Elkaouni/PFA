package com.spring.spring.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonDeserialize(as =ServiceComposite.class)
public class Service{ //implements IHandler{
  //  public IHandler chain;
    private int id_service;
    private String Nom;
    private String DataIn;
    private String DataOut;
    private int Priorite;
    private User Responsable;
    private String Public_cible;
    private Boolean composite;
    private String BDD;
    private int nbrFils=0;
    public Service(){}
    public Service(int id, String Nom, String DataIn, String DataOut, int Priorite, User Responsable, String Public_cible, String BDD, Boolean composite) {
        this.id_service=id ; this.Nom = Nom; this.DataIn = DataIn; this.DataOut = DataOut; this.Priorite = Priorite;
        this.Responsable = Responsable;this.Public_cible = Public_cible;
        this.composite=composite; this.BDD=BDD;
    }
    public int getId_service() {
        return id_service;
    }
    public void setId_service(int id_service) {
        this.id_service = id_service;
    }

    public String getBDD() {
        return BDD;
    }

    public void setBDD(String BDD) {
        this.BDD = BDD;
    }

    public String getNom() {
        return Nom;
    }
    public void setNom(String Nom) {
        this.Nom = Nom;
    }
    public String getDataIn() {
        return DataIn;
    }
    public void setDataIn(String DataIn) {
        this.DataIn = DataIn;
    }
    public String getDataOut() {
        return DataOut;
    }
    public void setDataOut(String DataOut) {
        this.DataOut = DataOut;
    }
    public int getPriorite() {
        return Priorite;
    }
    public void setPriorité(int Priorite) {
        this.Priorite = Priorite;
    }
    public User getResponsable() {
        return Responsable;
    }
    public void setResponsable(User Responsable) {
        this.Responsable = Responsable;
    }
    public String getPublic_cible() {
        return Public_cible;
    }
    public void setPublic_cible(String Public_cible) {
        this.Public_cible = Public_cible;
    }

    public Boolean getComposite() {
        return composite;
    }
    public int getNbrFils() {
        return nbrFils;
    }

    public void setNbrFils(int nbrFils) {
        this.nbrFils = nbrFils;
    }


    @Override
    public String toString() {
        return "Service{" +
                "id_service=" + id_service +
                ", Nom='" + Nom + '\'' +
                ", DataIn='" + DataIn + '\'' +
                ", DataOut='" + DataOut + '\'' +
                ", Priorité=" + Priorite +
                ", Responsable=" + Responsable +
                ", Public_cible='" + Public_cible + '\'' +
                ", composite=" + composite +
                ", BDD='" + BDD + '\'' +
                '}';
    }


}
