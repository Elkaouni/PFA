package com.spring.spring.model;

public interface IHandler {
    void setNext(IHandler next );
    void TryHandle(Requests request);
}
