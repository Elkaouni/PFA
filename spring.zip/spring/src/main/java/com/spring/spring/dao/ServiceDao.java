package com.spring.spring.dao;


import com.spring.spring.model.Service;
import com.spring.spring.model.User;

import java.util.ArrayList;
import java.util.List;

public interface ServiceDao {
     public ArrayList<Service> findAllServices();
     User findResById(int id);
     User findUserById(int id);
     Service findServiceById(int id);
      ArrayList<Service> findListOfChildren(int id_parent);

     int addService(int id, int id_resp, int id_parent, String nom, String cible, String datain, String dataout, int priority, String structure, int nb_fils, String BDD);
     int addResp(int id, String nom, String prenom, String contact, String email);
     int addUser(String nom,String prenom, String email, String contact, String password, int admin);
     int removeResp(int id);
     int removeUser(int id);
     void removeService(int id);

     public List<User> listUsers();

     public boolean authenticateUser(String email, String password);

}
